package edu.stanford.cs108.cityinformation;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Add extends AppCompatActivity {

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        db = openOrCreateDatabase("citiesDB",MODE_PRIVATE,null);
        //String setupStr = "CREATE TABLE IF NOT EXISTS countries ("
        //        + "city TEXT, country TEXT, population INTEGER,"
        //        + "_id INTEGER PRIMARY KEY AUTOINCREMENT"
        //        + ");";
        //db.execSQL(setupStr);
        //settingDB();
    }

    /*private void settingDB(){
        String dataStr = "INSERT INTO countries VALUES "
                + "('Cairo','Africa',15200000, NULL),"
                + "('Lagos','Africa',21000000, NULL),"
                + "('Kyoto','Asia', 1474570, NULL),"
                + "('Mumbai','Asia',20400000, NULL),"
                + "('Shanghai','Asia',24152700, NULL),"
                + "('Melbourne','Australia',3900000, NULL),"
                + "('London','Europe',8580000, NULL),"
                + "('Rome','Europe',2715000, NULL),"
                + "('Rostov-on-Don','Europe',1052000, NULL),"
                + "('San Francisco','North America',5780000, NULL),"
                + "('San Jose','North America',7354555, NULL),"
                + "('Rio de Janeiro','South America',12280702, NULL),"
                + "('Santiago','South America',5507282, NULL)"
                +";";
        db.execSQL(dataStr);
    } */

    public void addData(View view){
        //http://stackoverflow.com/questions/4531396/get-value-of-a-edit-text-field
        String sql = "INSERT INTO countries VALUES ";
        EditText nameEdit   = (EditText)findViewById(R.id.nameEdit);
        String city = nameEdit.getText().toString();
        EditText continentEdit   = (EditText)findViewById(R.id.continentEdit);
        String continent = continentEdit.getText().toString();
        EditText populationEdit   = (EditText)findViewById(R.id.population);
        int population = Integer.parseInt(populationEdit.getText().toString());
        sql = sql + "('" + city + "','" + continent + "'," + population + ",NULL);";
        db.execSQL(sql);
        String toastString = city + " added";
        Toast.makeText(getApplicationContext(), toastString, Toast.LENGTH_SHORT).show();
    }

}
