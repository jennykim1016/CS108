package edu.stanford.cs108.cityinformation;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SimpleCursorAdapter;

public class LookUp extends AppCompatActivity {

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_look_up);
        db = openOrCreateDatabase("citiesDB",MODE_PRIVATE,null);
        //String setupStr = "CREATE TABLE IF NOT EXISTS countries ("
        //        + "city TEXT, country TEXT, population INTEGER,"
        //        + "_id INTEGER PRIMARY KEY AUTOINCREMENT"
        //        + ");";
        //db.execSQL(setupStr);
        //settingDB();
    }

    private void settingDB(){
        String dataStr = "INSERT INTO countries VALUES "
                + "('Cairo','Africa',15200000, NULL),"
                + "('Lagos','Africa',21000000, NULL),"
                + "('Kyoto','Asia', 1474570, NULL),"
                + "('Mumbai','Asia',20400000, NULL),"
                + "('Shanghai','Asia',24152700, NULL),"
                + "('Melbourne','Australia',3900000, NULL),"
                + "('London','Europe',8580000, NULL),"
                + "('Rome','Europe',2715000, NULL),"
                + "('Rostov-on-Don','Europe',1052000, NULL),"
                + "('San Francisco','North America',5780000, NULL),"
                + "('San Jose','North America',7354555, NULL),"
                + "('Rio de Janeiro','South America',12280702, NULL),"
                + "('Santiago','South America',5507282, NULL)"
                +";";
        db.execSQL(dataStr);
    }

    public void onSearched(View view) {

        //http://stackoverflow.com/questions/4531396/get-value-of-a-edit-text-field
        String sql = "SELECT * FROM countries WHERE ";
        EditText nameEdit = (EditText) findViewById(R.id.nameEdit);
        String city = nameEdit.getText().toString();
        EditText continentEdit = (EditText) findViewById(R.id.continentEdit);
        String continent = continentEdit.getText().toString();
        EditText populationEdit = (EditText) findViewById(R.id.population);
        int population = 0;
        int condition = 0;
        if (populationEdit.getText().toString().trim().length() != 0) {
            population = Integer.parseInt(populationEdit.getText().toString());
        }
        RadioGroup lessgreat = (RadioGroup) findViewById(R.id.lessgreat);
        RadioButton checked = (RadioButton) findViewById(lessgreat.getCheckedRadioButtonId());
        String selectText = checked.getText().toString();


        //Log.d("LESS", less.getText().toString());
        //Log.d("LESS", ""+less.isSelected());
        //https://trinitytuts.com/tips/get-selected-radobutton-from-radiogroup-in-android/
        //String greatLess = selectedButton.getText().toString();
        String greatLess = "Greater or Equal";
        if (city.trim().length() == 0 && continent.trim().length() == 0 && populationEdit.getText().toString().trim().length() == 0) {
            sql = "SELECT * FROM countries";
        }
        if (city.trim().length() != 0) {
            sql = sql + "city LIKE " + "'" + city + "%" + "'";
            condition++;
        }

        if (continent.trim().length() != 0) {
            if (condition > 0) {
                sql = sql + " AND ";
            }
            sql = sql + "country LIKE " + "'" + continent + "%" +  "'";
            condition++;
        }


        if (populationEdit.getText().toString().trim().length() != 0) {
            if (condition > 0) {
                sql = sql + " AND ";
            }
            // unknown bug, this way the code works
            if (selectText.trim().length() > 10) {
                sql = sql + "population > " + population;
            } else {
                sql = sql + "population < " + population;
            }
        }

        ListView outputView = (ListView) findViewById(R.id.listView);

        String[] fromArray = {"city", "country", "population"};
        int[] toArray = {R.id.custom_text_1,R.id.custom_text_2,R.id.custom_text_3};
        Cursor cursor = db.rawQuery(sql,null);
        ListAdapter adapter = new SimpleCursorAdapter(this,R.layout.custom_list_item_3,cursor,fromArray,toArray,0);
        ListView listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(adapter);
    }

}
