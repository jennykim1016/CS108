package edu.stanford.cs108.cityinformation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class resetDB extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_db);
    }
}
