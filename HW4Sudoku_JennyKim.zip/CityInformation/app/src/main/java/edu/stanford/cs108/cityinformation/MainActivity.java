package edu.stanford.cs108.cityinformation;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;
import android.database.Cursor;

//https://developer.android.com/guide/topics/ui/ XML reference
// I copied many lines from the SQL handout (CS108 official handout)

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = openOrCreateDatabase("citiesDB",MODE_PRIVATE,null);
        /* String setupStr = "CREATE TABLE IF NOT EXISTS countries ("
                + "city TEXT, country TEXT, population INTEGER,"
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT"
                + ");";
        db.execSQL(setupStr);
        settingDB(); */

        Cursor tablesCursor = db.rawQuery("SELECT * FROM sqlite_master WHERE type='table' AND name='countries';", null);

        if (tablesCursor.getCount() == 0) {
            String setupStrb = "CREATE TABLE IF NOT EXISTS countries ("
                    + "city TEXT, country TEXT, population INTEGER,"
                    + "_id INTEGER PRIMARY KEY AUTOINCREMENT"
                    + ");";
            db.execSQL(setupStrb);
            settingDB();
        }
    }

    private void settingDB(){
        String dataStr = "INSERT INTO countries VALUES "
                + "('Cairo','Africa',15200000, NULL),"
                + "('Lagos','Africa',21000000, NULL),"
                + "('Kyoto','Asia', 1474570, NULL),"
                + "('Mumbai','Asia',20400000, NULL),"
                + "('Shanghai','Asia',24152700, NULL),"
                + "('Melbourne','Australia',3900000, NULL),"
                + "('London','Europe',8580000, NULL),"
                + "('Rome','Europe',2715000, NULL),"
                + "('Rostov-on-Don','Europe',1052000, NULL),"
                + "('San Francisco','North America',5780000, NULL),"
                + "('San Jose','North America',7354555, NULL),"
                + "('Rio de Janeiro','South America',12280702, NULL),"
                + "('Santiago','South America',5507282, NULL)"
                +";";
        db.execSQL(dataStr);
    }

    public void addClicked(View view){
        Intent intent = new Intent(this, Add.class);
        startActivity(intent);
    }

    public void lookupClicked(View view){
        Intent intent = new Intent(this, LookUp.class);
        startActivity(intent);
    }

    public void resetClicked(View view){
        Toast.makeText(getApplicationContext(), "Database Reset", Toast.LENGTH_SHORT).show();
        db.execSQL("DROP TABLE IF EXISTS countries");
        String setupStr = "CREATE TABLE IF NOT EXISTS countries ("
                + "city TEXT, country TEXT, population INTEGER,"
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT"
                + ");";
        db.execSQL(setupStr);
        settingDB();
        /*Cursor cursor = db.rawQuery("SELECT * FROM countries;",null);
        while (cursor.moveToNext()) {
            Log.d("HERE", cursor.getString(0));
        }*/
    }
}
