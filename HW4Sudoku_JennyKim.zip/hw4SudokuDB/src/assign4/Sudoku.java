package assign4;
//https://www.tutorialspoint.com/java/lang/system_currenttimemillis.htm

import java.util.*;
import java.util.SortedSet;
import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Queue;
import java.lang.*;
/*
 * Encapsulates a Sudoku grid to be solved.
 * CS108 Stanford.
 */
public class Sudoku {
	
	private int[][] grid;
	private int[][] solutionGrid;
	long startTime;
	long endTime;
	boolean solutionFound = false;
	int solutionCount = 0;
	ArrayList<Spot> unsortedSpot = new ArrayList<Spot>();
	//Queue<Spot> order = new LinkedList<Spot>();
	ArrayList<Spot> ordered = new ArrayList<Spot>();
	//private Set<Spot> sortedSpot = new TreeSet<Spot>();
	
	private class Spot{
		
		int value;
		int row;
		int column;
		ArrayList<Integer> possibleSet = new ArrayList<Integer>();
		int possibleSize;
		boolean initialFilled;
		
		private Spot(int i, int j, boolean filled){
			row = i;
			column = j;
			initialFilled = filled;
		}
		
		private void set(int i, int j, int val){
			grid[i][j] = val;
			value = val;
		}
		
		private void setPossibleSet(ArrayList<Integer> possible){
			possibleSet = possible;
			possibleSize = possible.size();
		}

		
		private ArrayList<Integer> getPossibleSet(){
			return possibleSet;
		}
		
		private Integer getRowNum(){
			return row;
		}
		
		private Integer getColumnNum(){
			return column;
		}
		
		
		
	}
	//http://javarevisited.blogspot.com/2013/10/what-is-priorityqueue-data-structure-java-example-tutorial.html
	/*Queue<String> order = new LinkedList<String>();
	Map<String, ArrayList<Integer>> valueMap = new HashMap<String, ArrayList<Integer>>();
	Map<Integer, ArrayList<String>> priorityMap = new HashMap<Integer, ArrayList<String>>();
	*/
	// Provided grid data for main/testing
	// The instance variable strategy is up to you.
	
	// Provided easy 1 6 grid
	// (can paste this text into the GUI too)
	public static final int[][] easyGrid = Sudoku.stringsToGrid(
	"1 6 4 0 0 0 0 0 2",
	"2 0 0 4 0 3 9 1 0",
	"0 0 5 0 8 0 4 0 7",
	"0 9 0 0 0 6 5 0 0",
	"5 0 0 1 0 2 0 0 8",
	"0 0 8 9 0 0 0 3 0",
	"8 0 9 0 4 0 2 0 0",
	"0 7 3 5 0 9 0 0 1",
	"4 0 0 0 0 0 6 7 9");
	
	// Provided medium 5 3 grid
	public static final int[][] mediumGrid = Sudoku.stringsToGrid(
	 "530070000",
	 "600195000",
	 "098000060",
	 "800060003",
	 "400803001",
	 "700020006",
	 "060000280",
	 "000419005",
	 "000080079");
	
	// Provided hard 3 7 grid
	// 1 solution this way, 6 solutions if the 7 is changed to 0
	public static final int[][] hardGrid = Sudoku.stringsToGrid(
	"3 7 0 0 0 0 0 8 0",
	"0 0 1 0 9 3 0 0 0",
	"0 4 0 7 8 0 0 0 3",
	"0 9 3 8 0 0 0 1 2",
	"0 0 0 0 4 0 0 0 0",
	"5 2 0 0 0 6 7 9 0",
	"6 0 0 0 2 1 0 4 0",
	"0 0 0 5 3 0 9 0 0",
	"0 3 0 0 0 0 0 5 1");
	
	
	public static final int SIZE = 9;  // size of the whole 9x9 puzzle
	public static final int PART = 3;  // size of each 3x3 part
	public static final int MAX_SOLUTIONS = 100;
	
	
	// Provided various static utility methods to
	// convert data formats to int[][] grid.
	
	/**
	 * Returns a 2-d grid parsed from strings, one string per row.
	 * The "..." is a Java 5 feature that essentially
	 * makes "rows" a String[] array.
	 * (provided utility)
	 * @param rows array of row strings
	 * @return grid
	 */
	public static int[][] stringsToGrid(String... rows) {
		int[][] result = new int[rows.length][];
		for (int row = 0; row<rows.length; row++) {
			result[row] = stringToInts(rows[row]);
		}
		return result;
	}
	
	
	/**
	 * Given a single string containing 81 numbers, returns a 9x9 grid.
	 * Skips all the non-numbers in the text.
	 * (provided utility)
	 * @param text string of 81 numbers
	 * @return grid
	 */
	public static int[][] textToGrid(String text) {
		int[] nums = stringToInts(text);
		if (nums.length != SIZE*SIZE) {
			throw new RuntimeException("Needed 81 numbers, but got:" + nums.length);
		}
		
		int[][] result = new int[SIZE][SIZE];
		int count = 0;
		for (int row = 0; row<SIZE; row++) {
			for (int col=0; col<SIZE; col++) {
				result[row][col] = nums[count];
				count++;
			}
		}
		return result;
	}
	
	
	/**
	 * Given a string containing digits, like "1 23 4",
	 * returns an int[] of those digits {1 2 3 4}.
	 * (provided utility)
	 * @param string string containing ints
	 * @return array of ints
	 */
	public static int[] stringToInts(String string) {
		int[] a = new int[string.length()];
		int found = 0;
		for (int i=0; i<string.length(); i++) {
			if (Character.isDigit(string.charAt(i))) {
				a[found] = Integer.parseInt(string.substring(i, i+1));
				found++;
			}
		}
		int[] result = new int[found];
		System.arraycopy(a, 0, result, 0, found);
		return result;
	}


	// Provided -- the deliverable main().
	// You can edit to do easier cases, but turn in
	// solving hardGrid.
	public static void main(String[] args) {
		Sudoku sudoku;
		sudoku = new Sudoku(hardGrid);
		
		System.out.println(sudoku); // print the raw problem
		int count = sudoku.solve();
		System.out.println("solutions:" + count);
		System.out.println("elapsed:" + sudoku.getElapsed() + "ms");
		System.out.println(sudoku.getSolutionText());
	}
	
	

	/**
	 * Sets up based on the given ints.
	 */
	public Sudoku(int[][] ints) {
		solutionGrid = new int[SIZE][SIZE];
		grid = ints;
		
		for(int i=0; i<SIZE; i++){
			for(int j=0; j<SIZE; j++){
				if(grid[i][j]==0){
					initialize(i, j);
				} else {
					// do nothing
				}
			}
		}
		for(int i=1; i<=9; i++){
			for(Spot s: unsortedSpot){
				if(s.possibleSize==i){
					ordered.add(s);
				}
			}
		}
	}
	
	private void initialize(int x, int y){
		//System.out.println("HEREEE");
		/*for(int i=0; i<SIZE; i++){
			//http://stackoverflow.com/questions/10904911/how-to-convert-an-int-array-to-string-with-tostring-method-in-java
			System.out.println(Arrays.toString(grid[i]));
		}*/
		//System.out.println(x);
		//System.out.println(y);
		Spot currentSpot = new Spot(x, y, false);
		ArrayList<Integer> canContain = new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
		for(int i=0; i<SIZE; i++){
			//System.out.println(canContain.toString());
			if(grid[x][i]!=0){
				if(canContain.contains(grid[x][i])){
					//System.out.println(grid[x][i]);
					canContain.remove(Integer.valueOf(grid[x][i]));
				}
			}
			if(grid[i][y]!=0){
				if(canContain.contains(grid[i][y])){
					//System.out.println(grid[i][y]);
					canContain.remove(Integer.valueOf(grid[i][y]));
				}
			}
		}
		for(int i=0; i<3; i++){
			for(int j=0; j<3; j++){
				//System.out.println(grid[(x/3)*3+i][(y/3)*3+j]);
				if(grid[(x/3)*3+i][(y/3)*3+j]!=0 && canContain.contains(grid[(x/3)*3+i][(y/3)*3+j])){
					canContain.remove(Integer.valueOf(grid[(x/3)*3+i][(y/3)*3+j]));;
					//System.out.println(canContain.toString());
				}
			}
		}
		currentSpot.setPossibleSet(canContain);
		currentSpot.possibleSize = canContain.size();
		unsortedSpot.add(currentSpot);
	}
	
	private boolean checkValidSquare(int[][] gridCopy){
		for(int i=0; i<9; i++){
			Set<Integer> row = new HashSet<Integer>();
			Set<Integer> column = new HashSet<Integer>();
			for(int j=0; j<9; j++){
				if(gridCopy[i][j]!=0){
				row.add(gridCopy[i][j]);
				}
				if(gridCopy[j][i]!=0){
				column.add(gridCopy[j][i]);
				}
			}
			if(row.size()!=9 || column.size()!=9) return false;
		}
		for(int i=0; i<9; i=i+3){
			for(int j=0; j<9; j=j+3){
			if(!checkValidSquareSol(i,j, gridCopy)) return false;
			}
		}
		return true;
	}
	
	private boolean checkValidSquareSol(int rowNum, int colNum, int[][] gridCopy){
		Set<Integer> square = new HashSet<Integer>();
		for(int i=rowNum; i<rowNum+3; i++){
			for(int j=colNum; j<colNum+3; j++){
				if(gridCopy[i][j]!=0){
				square.add(gridCopy[i][j]);
				}
			}
		}
		if(square.size()==9) return true;
		return false;
	}
	
	private boolean checkGrid(int[][] gridCopy){
		for(int i=0; i<9; i++){
			//http://stackoverflow.com/questions/2041778/how-to-initialize-hashset-values-by-construction
			Set<Integer> column = new HashSet<Integer>(Arrays.asList(1,2,3,4,5,6,7,8,9));
			Set<Integer> row = new HashSet<Integer>(Arrays.asList(1,2,3,4,5,6,7,8,9));
			for(int j=0; j<9; j++){
				if(gridCopy[i][j]!=0){
					if(row.contains(gridCopy[i][j])){
						row.remove(gridCopy[i][j]);
					} else {
						return false;
					}
				}
				if(gridCopy[j][i]!=0){
					if(column.contains(gridCopy[j][i])){
						column.remove(gridCopy[j][i]);
					} else {
						return false;
					}
				}
			}
		}
		for(int i=0; i<9; i=i+3){
			for(int j=0; j<9; j=j+3){
			if(!checkValidSquare(i,j, gridCopy)) return false;
			}
		}
		return true;
	}
	
	private boolean checkValidSquare(int rowNum, int colNum, int[][] gridCopy){
		Set<Integer> square = new HashSet<Integer>(Arrays.asList(1,2,3,4,5,6,7,8,9));
		for(int i=rowNum; i<rowNum+3; i++){
			for(int j=colNum; j<colNum+3; j++){
				if(gridCopy[i][j]!=0){
					if(square.contains(gridCopy[i][j])){
						square.remove(gridCopy[i][j]);
					} else {
						return false;
					}
				}
			}
		}
		return true;
	}
	
	
	/**
	 * Solves the puzzle, invoking the underlying recursive search.
	 */
	public int solve() {
		startTime = System.currentTimeMillis();
		int count = solveHelper(grid, 0, 0);
		solutionCount = count;
		endTime = System.currentTimeMillis();
		return count; // YOUR CODE HERE
	}
	
	//https://see.stanford.edu/materials/icspacs106b/H19-RecBacktrackExamples.pdf
	//https://www.cs.utexas.edu/~scottm/cs314/handouts/slides/Topic13RecursiveBacktracking.pdf
	//http://stackoverflow.com/questions/19883097/java-path-from-top-to-the-bottom-of-the-grid
	private int solveHelper(int[][] grid, int count, int num){
		if(solutionCount==100){
			return 0;
		}
		if(checkValidSquare(grid)){
			solutionCount++;
			if(!solutionFound){
				for(int i=0; i<grid.length; i++){
					solutionGrid[i] = grid[i].clone();
				}
				solutionFound=true;
			}
			return count+1;
		}
		/*for(int i=0; i<SIZE; i++){
			//http://stackoverflow.com/questions/10904911/how-to-convert-an-int-array-to-string-with-tostring-method-in-java
			System.out.println(Arrays.toString(grid[i]));
		}*/
		if(num >= ordered.size()) {
			return count + 0;
		}
		if(!checkGrid(grid)) {
			return count + 0;
		}
		//System.out.println("HERE");
		int[][] gridCopy = new int[SIZE][SIZE];
		for(int i=0; i<grid.length; i++){
			gridCopy[i] = grid[i].clone();
		}
		Spot currentSpot = ordered.get(num);
		ArrayList<Integer> allowedNums = currentSpot.getPossibleSet();
		int x = currentSpot.getRowNum();
		int y = currentSpot.getColumnNum();
		for(int nums:allowedNums){
			//System.out.println(x);
			//System.out.println(y);
			gridCopy[x][y] = nums;
			count = count + solveHelper(gridCopy, count, num+1);
		}
		return solutionCount;
		//if(count>100) return 100;
		//return count;
	}
	
	@Override
	public String toString() {
		//http://www.javatpoint.com/StringBuilder-class
		//http://stackoverflow.com/questions/14534767/how-to-append-a-newline-to-stringbuilder
		StringBuilder sb=new StringBuilder();
		for(int i=0; i<SIZE; i++){
			for(int j=0; j<SIZE; j++){
				sb.append(""+grid[i][j]);
				if(j!=SIZE-1){
					sb.append(" ");
				} else{
					if(i!=SIZE-1){
						sb.append("\n");
					}
				}
			}
		}
		//http://stackoverflow.com/questions/5278204/passing-and-returning-stringbuilders-java
		return sb.toString();
	}
	
	public String getSolutionText() {
		//http://www.javatpoint.com/StringBuilder-class
		StringBuilder sb=new StringBuilder();
		if(solutionCount==0){
			return "";
		} else {
			for(int i=0; i<SIZE; i++){
				for(int j=0; j<SIZE; j++){
					sb.append(""+solutionGrid[i][j]);
					if(j!=SIZE-1){
						sb.append(" ");
					} else{
						if(i!=SIZE-1){
							sb.append("\n");
						}
					}
				}
			}
		}
		return sb.toString(); // YOUR CODE HERE
	}
	
	public long getElapsed() {
		long duration = endTime - startTime;
		return duration; // YOUR CODE HERE
	}

}
