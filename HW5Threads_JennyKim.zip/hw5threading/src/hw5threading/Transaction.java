package hw5threading;

public class Transaction {
	
	int to;
	int from;
	int amount;
	
	public Transaction(int toGiven, int fromGiven, int amountGiven){
		to = toGiven;
		from = fromGiven;
		amount = amountGiven;
	}

}
