package hw5threading;

import java.util.concurrent.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.io.IOException;
import java.lang.InterruptedException;

/*The Bank class maintains a list of accounts and the BlockingQueue 
 * used to communicate between the main thread and the worker threads.  
 * The Bank is also responsible for starting up the worker threads, 
 * reading transactions from the file, and printing out all the account values 
 * when everything is done.  Note: make sure you start up all the worker threads 
 * before reading the transactions from the file.*/

public class Bank extends Thread {
	private int count = 0;
	private int id;
	private int currentBalance;
	private int numTrans;
	private static CountDownLatch latch;
	private static BlockingQueue<Transaction> queue;
	
	//private final Transaction nullTrans = new Transaction(-1,0,0);
	//private Transaction nullTrans = new Transaction(-1,0,0);

	//https://coderanch.com/t/376762/java/ArrayList-maintain-order
	//Our bank will track the balances in twenty different accounts. 
	//When the program begins, each of the accounts contains $1000.
	private static ArrayList<Account> accountList = new ArrayList<Account>(){{
		for(int i=0; i<20; i++){
			add(new Account(1000));
		}
	}};

	public static void main(String[] args) {
		//https://canvas.stanford.edu/courses/55720/files?preview=1474724
		//https://docs.oracle.com/javase/7/docs/api/java/util/StringTokenizer.html?is-external=true

		queue = new ArrayBlockingQueue<Transaction>(1);
		//System.out.println(queue.size());
		int numWorkers = Integer.parseInt(args[1]);
		latch = new CountDownLatch(numWorkers);
		Worker[] workers = new Worker[numWorkers];
		for(int i=0; i<numWorkers; i++){
			//http://stackoverflow.com/questions/4701927/the-method-start-is-undefined-for-the-type-serverworker-java-runnable
			//workers[i] = new Worker(queue);
			workers[i] = new Worker();
			workers[i].start();
		}
		//System.out.println("1");
		//System.out.println(queue.size());

		//http://stackoverflow.com/questions/18551251/how-to-open-a-text-file
		String process;

		//http://www.mkyong.com/java/how-to-read-file-from-java-bufferedreader-example/
		try(BufferedReader stringReader = new BufferedReader(new FileReader(args[0]))){
			process = stringReader.readLine();

			while(process != null)
			{
				String[] result = process.split("\\s");
				Transaction currentTrans = new Transaction(Integer.parseInt(result[0]), 
						Integer.parseInt(result[1]), Integer.parseInt(result[2]));
				try{
					queue.put(currentTrans);
					//System.out.println("2");
					//System.out.println(queue.size());
				} catch (InterruptedException e) {

				}
				process = stringReader.readLine();
			}
		} catch (IOException e){
			//
		}
		try{
			for(int i=0; i<queue.size(); i++){
				queue.put(new Transaction(-1,0,0));
				//System.out.println("3");
				//System.out.println(queue.size());
				//System.out.println(queue.size());
			}
		} catch (InterruptedException e) {

		}

		try{
			latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		for(int i=0; i<20; i++){
			Account currAccount = accountList.get(i);
			currAccount.printStatus(i);
		}
	}

	/*I recommend making the Worker class is an inner class of the Bank class.  
	 * This way it gets easy access to the list of accounts and the queue used for communication.  
	 * Workers should check the queue for transactions.  
	 * If they find a transaction they should process it.  
	 * If the queue is empty, they will wait for the Bank class to read in another transaction 
	 * (you’ll get this behavior for free by using a BlockingQueue).  
	 * Workers terminate when all the transactions have been processed. 
	 *  We’ll discuss ways to communicate this below.*/

	public static class Worker extends Thread{

		//BlockingQueue<Transaction> queue;

		//public Worker(BlockingQueue<Transaction> inputQueue){
		public Worker(){
			//queue = inputQueue;
		}

		@Override
		public void run(){
			try{
				while(true){
					Transaction trans = queue.take();
					if (trans == null){
						break;
					}
					if (trans.to == -1){
						break;
					}
					Account toAccount = accountList.get(trans.to);
					Account fromAccount = accountList.get(trans.from);

					// check whether this changes the value
					synchronized(toAccount){
						toAccount.subtract(trans.amount);
						
					}
					
					synchronized(fromAccount){
						fromAccount.add(trans.amount);
					}
					
					latch.countDown();
				}
			} catch (InterruptedException e){
				e.printStackTrace();
			}
		}

	}

}
