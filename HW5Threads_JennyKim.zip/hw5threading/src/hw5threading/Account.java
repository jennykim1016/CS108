package hw5threading;

/*Account needs to store an id number, the current balance for the account, 
 * and the number of transactions that have occurred on the account.  
 * Remember that multiple worker threads may be accessing an account simultaneously 
 * and you must ensure that they cannot corrupt its data.  
 * You may also want to override the toString method to handle printing of account information.*/

public class Account {
	
	private int money;
	private int trans;
	
	public Account(int initialMoney){
		money = initialMoney;
		trans = 0;
	}
	
	public void subtract(int value){
		money = money-value;
		trans++;
	}
	
	public void add(int value){
		money = money+value;
		trans++;
	}
	
	public void printStatus(int accountNumb){
		System.out.print("acct:" + accountNumb+ " ");
		System.out.print("bal:" + money + " ");
		System.out.println("trans:" + trans);
		
	}

}
