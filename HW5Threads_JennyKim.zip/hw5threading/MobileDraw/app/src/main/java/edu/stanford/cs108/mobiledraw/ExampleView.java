package edu.stanford.cs108.mobiledraw;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

import java.util.ArrayList;

/**
 * Created by Jenny on 2/20/17.
 */

public class ExampleView extends View {

    Canvas canvas;
    private RadioButton erase;
    private RadioButton select;
    private RadioButton oval;
    private RadioButton rect;
    private GObject selectedObject;
    private EditText xText;
    private EditText yText;
    private EditText widthText;
    private EditText heightText;


    private Paint blueOutlinePaint;
    Paint redOutlinePaint;
    Paint whiteFill;

    private ArrayList<GObject> gObjectSet;
    View v;

    public ExampleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        //http://stackoverflow.com/questions/9228777/findviewbyid-not-working-in-a-not-mainactivity-class
        init();
        canvas = new Canvas();
        gObjectSet = new ArrayList<GObject>();
    }

    private void init(){
        redOutlinePaint = new Paint();
        redOutlinePaint.setColor(Color.RED);
        redOutlinePaint.setStyle(Paint.Style.STROKE);
        redOutlinePaint.setStrokeWidth(5.0f);
        blueOutlinePaint = new Paint();
        blueOutlinePaint.setColor(Color.BLUE);
        blueOutlinePaint.setStyle(Paint.Style.STROKE);
        blueOutlinePaint.setStrokeWidth(15.0f);
        whiteFill = new Paint();
        whiteFill.setColor(Color.WHITE);
        whiteFill.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        for(GObject obj: gObjectSet){
            float left = obj.left;
            float right = obj.right;
            float bottom = obj.bottom;
            float up = obj.top;
            String type = obj.shape;
            Paint objectPaint;
            if(obj == selectedObject){
                objectPaint = blueOutlinePaint;
            } else {
                objectPaint = redOutlinePaint;
            }
            if(type=="rect"){

                canvas.drawRect(left, up, right, bottom, objectPaint);
                canvas.drawRect(left, up, right, bottom, whiteFill);

            } else if(type=="oval"){

                canvas.drawOval(left, up, right, bottom, objectPaint);
                canvas.drawOval(left, up, right, bottom, whiteFill);

            }
        }
    }

     public void UpdatePosition(){
         float x = Float.parseFloat(xText.getText().toString());
         float y = Float.parseFloat(yText.getText().toString());
         float width = Float.parseFloat(widthText.getText().toString());
         float height = Float.parseFloat(heightText.getText().toString());
         GObject copyObject = new GObject(x, x+width, y, y+height, selectedObject.shape);
         gObjectSet.remove(selectedObject);
         selectedObject = copyObject;
         gObjectSet.add(copyObject);
         invalidate();
         /*GObject copyObject = selectedObject;
         copyObject.left = (float) x;
         copyObject.right = (float) (x + width);
         copyObject.bottom = (float) (y + height);
         copyObject.top = (float) (y);
         copyObject.height = (float) height;
         copyObject.width = (float) width;
         gObjectSet.remove(selectedObject);
         gObjectSet.add(copyObject);*/
         //invalidate();
    }

    float x1 = 0;
    float x2 = 0;
    float y1 = 0;
    float y2 = 0;
    float left = 0;
    float right = 0;
    float top = 0;
    float bottom = 0;
    GObject gob;

    @Override
    public boolean onTouchEvent(MotionEvent e){
        // refered a lot from the lecture example
        erase = (RadioButton) ((Activity) getContext()).findViewById(R.id.eraseButton);
        oval = (RadioButton) ((Activity) getContext()).findViewById(R.id.ovalButton);
        rect = (RadioButton) ((Activity) getContext()).findViewById(R.id.rectButton);
        select = (RadioButton) ((Activity) getContext()).findViewById(R.id.selectButton);
        xText = (EditText) ((Activity) getContext()).findViewById(R.id.xEdit);
        yText = (EditText) ((Activity) getContext()).findViewById(R.id.yEdit);
        widthText = (EditText) ((Activity) getContext()).findViewById(R.id.widthEdit);
        heightText = (EditText) ((Activity) getContext()).findViewById(R.id.heightEdit);
        //  This should work for any two diagonally opposite corners,
        // for example dragging from bottom-left to top-right should work just as well as top-left to bottom-right.
        if(oval.isChecked() || rect.isChecked()){

            switch (e.getAction()) {
                //http://stackoverflow.com/questions/22043525/how-to-get-initial-x-y-values-of-first-touch-action-down-in-ontouchlistener

                /* case MotionEvent.ACTION_MOVE:
                    finalX = e.getX();
                    finalY = e.getY();
                    break;

                case MotionEvent.ACTION_DOWN:
                    initX = e.getX();
                    initY = e.getY();
                    break;

                case MotionEvent.ACTION_UP:
                    GObject gob; */

                case MotionEvent.ACTION_DOWN:
                    x1 = e.getX();
                    y1 = e.getY();
                    //System.out.println("YO WA");
                    //System.out.println(""+x1);
                    //System.out.println(""+y1);
                    break;

                case MotionEvent.ACTION_UP:
                    x2 = e.getX();
                    y2 = e.getY();

                    if (x1>x2) {
                        left = x2;
                        right = x1;
                    } else {
                        left = x1;
                        right = x2;
                    }

                    if (y1>y2) {
                        top = y2;
                        bottom = y1;
                    } else {
                        top = y1;
                        bottom = y2;
                    }

                    if(rect.isChecked()) {
                        gob = new GObject(left, right, top, bottom, "rect");
                    } else {
                        gob = new GObject(left, right, top, bottom, "oval");
                    }

                    selectedObject = gob;
                    gObjectSet.add(gob);
                    break;

                default: break;
            }
            invalidate();
        } else if(erase.isChecked()){

            float checkedX = -1;
            float checkedY = -1;

            switch (e.getAction()) {
                //http://stackoverflow.com/questions/22043525/how-to-get-initial-x-y-values-of-first-touch-action-down-in-ontouchlistener

                case MotionEvent.ACTION_DOWN:
                    checkedX = e.getX();
                    checkedY = e.getY();
                    break;

                default: break;
            }

            boolean removed = false;
            for(int i=gObjectSet.size()-1; i>=0; i--){
                if(!removed) {
                    GObject obj = gObjectSet.get(i);
                    if(checkedX>(obj.left) && checkedX<(obj.right)) {
                        if (checkedY < (obj.bottom) && checkedY > (obj.top)) {
                            gObjectSet.remove(i);
                            removed=true;
                            selectedObject = null;
                        }
                    }
                }
            }
            invalidate();

        } else if(select.isChecked()){

            float checkedX = -1;
            float checkedY = -1;

            switch (e.getAction()) {
                //http://stackoverflow.com/questions/22043525/how-to-get-initial-x-y-values-of-first-touch-action-down-in-ontouchlistener

                case MotionEvent.ACTION_UP:
                    checkedX = e.getX();
                    checkedY = e.getY();
                    break;

                default: break;
            }

            boolean selected=false;

            for(int i=gObjectSet.size()-1; i>=0; i--){
                if(!selected) {
                    GObject obj = gObjectSet.get(i);
                    /*System.out.println("********&&&&&&&***********");
                    System.out.println("SELECTED");
                    System.out.println("checkX");
                    System.out.println(""+checkedX);
                    System.out.println("checkY");
                    System.out.println(""+checkedY);
                    System.out.println("LEFT");
                    System.out.println(""+obj.left);
                    System.out.println("RIGHT");
                    System.out.println(""+obj.right);
                    System.out.println("TOP");
                    System.out.println(""+obj.top);
                    System.out.println("BOTTOM");
                    System.out.println(""+obj.bottom);*/

                    if(checkedX>(obj.left) && checkedX<(obj.right)) {
                        if (checkedY < (obj.bottom) && checkedY > (obj.top)) {
                            gObjectSet.remove(i);
                            gObjectSet.add(obj);
                            selectedObject = obj;
                            xText.setText(""+obj.left);
                            yText.setText(""+obj.top);
                            widthText.setText(""+obj.width);
                            heightText.setText(""+obj.height);
                        }
                    }
                }
            }
            invalidate();
        }
        return true;
    }

    private class GObject{
        //float x;
        //float y;
        float left;
        float right;
        float top;
        float bottom;
        float width;
        float height;
        String shape;

        //private GObject(float xPoint, float yPoint, float widthReal, float widthHeight, String type, boolean checked){
        private GObject(float leftP, float rightP, float topP, float bottomP, String type){
            left = leftP;
            right = rightP;
            top = topP;
            bottom = bottomP;
            width = Math.abs(leftP-rightP);
            height = Math.abs(topP-bottomP);
            shape=type;
        }
    }
}
