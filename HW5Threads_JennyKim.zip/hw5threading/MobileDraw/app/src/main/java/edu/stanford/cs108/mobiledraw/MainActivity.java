package edu.stanford.cs108.mobiledraw;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    private ExampleView canvas;
    private RadioButton erase;
    private RadioButton select;
    private RadioButton oval;
    private RadioButton rect;

    //http://stackoverflow.com/questions/30660176/calling-custom-view-from-main-activity-message-in-ondraw-is-printed-but-cust
    //http://stackoverflow.com/questions/9228777/findviewbyid-not-working-in-a-not-mainactivity-class
    //http://stackoverflow.com/questions/8408197/android-landscape-only-orientation

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //CustomView exampleView = new CustomView(this);


        erase = (RadioButton) findViewById(R.id.eraseButton);
        Log.d("HERE", "MGS");
        oval = (RadioButton) findViewById(R.id.ovalButton);
        rect = (RadioButton) findViewById(R.id.rectButton);
        select = (RadioButton) findViewById(R.id.selectButton);
        canvas = (ExampleView) findViewById(R.id.canvas);
    }

    public void Update(View view){
        canvas.UpdatePosition();
    }




}