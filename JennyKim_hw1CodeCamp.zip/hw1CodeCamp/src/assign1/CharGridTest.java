// Test cases for CharGrid -- a few basic tests are provided.
package assign1;

import static org.junit.Assert.*;
import org.junit.Test;

public class CharGridTest {
	
	@Test
	public void testCharArea1() {
		char[][] grid = new char[][] {
				{'a', 'y', ' '},
				{'x', 'a', 'z'},
			};
		
		
		CharGrid cg = new CharGrid(grid);
				
		assertEquals(4, cg.charArea('a'));
		assertEquals(1, cg.charArea('z'));
	}
	
	
	@Test
	public void testCharArea2() {
		char[][] grid = new char[][] {
				{'c', 'a', ' '},
				{'b', ' ', 'b'},
				{' ', ' ', 'a'}
			};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(6, cg.charArea('a'));
		assertEquals(3, cg.charArea('b'));
		assertEquals(1, cg.charArea('c'));
	}
	
	@Test
	public void testCharArea3() {
		char[][] grid = new char[][] {
				{'c', 'z', ' '},
				{'b', ' ', 'z'},
				{'z', ' ', 'a'}
			};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(9, cg.charArea('z'));
		assertEquals(1, cg.charArea('b'));
		assertEquals(1, cg.charArea('a'));
	}
	
	@Test
	public void testCharArea4() {
		char[][] grid = new char[][] {
				{'c', 'z', ' ', ' '},
				{'b', ' ', 'z', 'a'},
				{'z', ' ', 'a', 'z'}
			};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(12, cg.charArea('z'));
		assertEquals(9, cg.charArea(' '));
		assertEquals(4, cg.charArea('a'));
	}
	
	@Test
	public void testCharArea5() {
		char[][] grid = new char[][] {
				{'c', 'z', ' ', ' ', ' '},
				{'b', ' ', 'z', 'c', ' '},
				{'z', ' ', 'a', 'z', 'z'}
			};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(15, cg.charArea('z'));
		assertEquals(12, cg.charArea(' '));
		assertEquals(8, cg.charArea('c'));
	}
	
	@Test
	public void testCountPlus1() {
		char[][] grid = new char [][] {
				{'x', 'a', 'x'},
				{'a', 'a', 'a'},
				{'x', 'a', 'x'},
		};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(1, cg.countPlus());
	}
	
	@Test
	public void testCountPlus2() {
		char[][] grid = new char [][] {
				{'x', 'a', 'x', 's', 's'},
				{'a', 'a', 'x', 'x', 's'},
				{'x', 'a', 'x', 'x', 'x'},
				{'x', 'a', 's', 'x', 's'},
				{'a', 's', 's', 's', 'y'},
				{'x', 'a', 's', 'x', 'x'},
				
		};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(2, cg.countPlus());
	}
	
	@Test
	public void testCountPlus3() {
		char[][] grid = new char [][] {
				{'x', 'a', 'x', 's', 's'},
				{'a', 'a', 'a', 'x', 's'},
				{'x', 'a', 'x', 'x', 'x'},
				{'x', 'x', 's', 'x', 's'},
				{'a', 's', 's', 's', 'y'},
				{'x', 'a', 's', 'x', 'x'},
				
		};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(3, cg.countPlus());
	}
	
	@Test
	public void testCountPlus4() {
		char[][] grid = new char [][] {
				{'x', 'x'},
				{'x', 'x'},
				
		};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(0, cg.countPlus());
	}
	
	@Test
	public void testCountPlus5() {
		char[][] grid = new char [][] {
				{'x', 'x', 'a'},
				{'x', 'x', 'x'},
				{'a', 'x', 'a'},
				
		};
		
		CharGrid cg = new CharGrid(grid);
		
		assertEquals(1, cg.countPlus());
	}
	
}
