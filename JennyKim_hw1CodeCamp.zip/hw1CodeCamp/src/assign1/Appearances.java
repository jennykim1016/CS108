package assign1;

import java.util.*;

public class Appearances {
	
	/**
	 * Returns the number of elements that appear the same number
	 * of times in both collections. Static method. (see handout).
	 * @return number of same-appearance elements
	 */
	public static <T> int sameCount(Collection<T> a, Collection<T> b) {
		
		int count = 0;
		
		/* Initialize a map about Collection a */
		Map <T, Integer> aMap = new HashMap<T, Integer>();
		Iterator<T> itA = a.iterator();
		while(itA.hasNext()){
			T element = itA.next();
			if(aMap.containsKey(element)){
				int countA = aMap.get(element) + 1;
				aMap.put(element, countA);
			} else {
				aMap.put(element, 1);
			}
		}
		
		/* Initialize a map about Collection b */
		Map<T, Integer> bMap = new HashMap<T, Integer>();
		Iterator<T> itB = b.iterator();
		while(itB.hasNext()){
			T element = itB.next();
			if(bMap.containsKey(element)){
				int countB = bMap.get(element) + 1;
				bMap.put(element, countB);
			} else {
				bMap.put(element, 1);
			}
		}
		
		for (T key : aMap.keySet()){
			if(aMap.containsKey(key) && bMap.containsKey(key)){
				int aValue = aMap.get(key);
				int bValue = bMap.get(key);
				if(aValue == bValue){
					count++;
				}
			}
		}
			
		return count;
	}
	
}
