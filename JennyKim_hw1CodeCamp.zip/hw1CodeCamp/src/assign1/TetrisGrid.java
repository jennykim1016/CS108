//
// TetrisGrid encapsulates a tetris board and has
// a clearRows() capability.
package assign1;
import java.util.Arrays;

public class TetrisGrid {
	
	private boolean[][] grid;
	
	/**
	 * Constructs a new instance with the given grid.
	 * Does not make a copy.
	 * @param grid
	 */
	public TetrisGrid(boolean[][] grid) {
		this.grid = grid;
	}
	
	
	/**
	 * Does row-clearing on the grid (see handout).
	 */
	public void clearRows() {
		for(int y=0; y<grid[0].length; y++){
			//System.out.println("ITERATION");
			//System.out.println(y);
			boolean isTrue = true;
			for(int x=0; x<grid.length; x++){
				//System.out.println(grid[x][y]);
				if(!grid[x][y]) isTrue = false;
			}
			if(isTrue){
				boolean[][] newGrid = new boolean[grid.length][grid[0].length];
				for(int i=0; i<grid.length; i++){
					for(int j=0; j<y; j++){
						/* System.out.println("1st");
						System.out.println("Y");
						System.out.println(j);
						System.out.println("X");
						System.out.println(i); */
						newGrid[i][j] = grid[i][j];
					}
					/* System.out.println("BUGGY");''
					System.out.println("Y");
					System.out.println(y+1);
					System.out.println(grid[0].length-1); */
					for(int j=y+1; j<=grid[0].length-1; j++){
						/* System.out.println("2nd");
						System.out.println("Y");
						System.out.println(j);
						System.out.println("X");
						System.out.println(i);
						System.out.println(grid[i][j]); */
						newGrid[i][j-1] = grid[i][j];
						//System.out.println(newGrid[i][j-1]);
					}
					/*System.out.println("3rd");
					System.out.println("Y");
					System.out.println(grid[0].length-1);
					System.out.println("X");
					System.out.println(i); */
					newGrid[i][grid[0].length-1]=false;
				}
				y=y-1;
				this.grid=newGrid;
			}
		}
	}
	
	/**
	 * Returns the internal 2d grid array.
	 * @return 2d grid array
	 */
	boolean[][] getGrid() {
		return grid;
	}
}
