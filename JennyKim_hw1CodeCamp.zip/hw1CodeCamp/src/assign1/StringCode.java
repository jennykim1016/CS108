package assign1;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

// CS108 HW1 -- String static methods

public class StringCode {

	/**
	 * Given a string, returns the length of the largest run.
	 * A a run is a series of adjacent chars that are the same.
	 * @param str
	 * @return max run length
	 */
	public static int maxRun(String str) {
		int maxLength = 0;
		int currentLength = 0;
		String prevChar = null;
		for(int i=0; i<str.length(); i++){
			String currentChar = ""+str.charAt(i);
			//System.out.println("DEBUG STARTED");
			//System.out.println(i);
			//System.out.println(currentChar);
			if(prevChar == null){
				//System.out.println("NULL");
				currentLength = 1;
			//http://stackoverflow.com/questions/7375427/comparing-two-identical-strings-with-returns-false
			} else if(prevChar.equalsIgnoreCase(currentChar)){
				currentLength++;
				//System.out.println("SAME");
			} else {
				//System.out.println("HERE");
				currentLength = 1;
			}
			//System.out.println(currentLength);
			if(maxLength < currentLength){
				maxLength = currentLength;
			}
			prevChar = currentChar;
		}
		return maxLength;
	}

	
	/**
	 * Given a string, for each digit in the original string,
	 * replaces the digit with that many occurrences of the character
	 * following. So the string "a3tx2z" yields "attttxzzz".
	 * @param str
	 * @return blown up string
	 */
	public static String blowup(String str) {
		String result = "";
		for(int i = 0; i<str.length(); i++){
			char character = str.charAt(i);
			if(isInteger(character)){
				i = i+1;
				if(i>=str.length()) return result;
				char posChar = str.charAt(i);
				for(int j=0; j<Integer.parseInt(""+character); j++){
					result = result + posChar;
				}
				i = i-1;
			} else {
				result = result + character;
			}
		}
		return result;
	}
	
	//http://stackoverflow.com/questions/5439529/determine-if-a-string-is-an-integer-in-java
	private static boolean isInteger(char ch){
		try{
			Integer.parseInt(""+ch);
			return true;
		} catch (NumberFormatException e){
			return false;
		}
	}
	
	/**
	 * Given 2 strings, consider all the substrings within them
	 * of length len. Returns true if there are any such substrings
	 * which appear in both strings.
	 * Compute this in linear time using a HashSet. Len will be 1 or more.
	 */
	public static boolean stringIntersect(String a, String b, int len) {
		HashSet<String> set = new HashSet<>();
		//System.out.println("YOYOYO");
		if(a.length() < len) return false;
		for(int i=0; i<a.length()-len+1; i++){
			//System.out.println("YOYOYO");
			String subst = a.substring(i, i+len);
			//System.out.println("A SUBSTRING");
			//System.out.println(subst);
			set.add(subst);
		}
		if(b.length() < len) return false;
		for(int j=0; j<(b.length()-len+1); j++){
			//System.out.println("YOYOYO");
			String subst = b.substring(j, j+len);
			//System.out.println("B SUBSTRING");
			//System.out.println(subst);
			if(set.contains(subst)){
				return true;
			}
		}
		return false;
	}
}
