/*
 HW1 Taboo problem class.
 Taboo encapsulates some rules about what objects
 may not follow other objects.
 (See handout).
*/
package assign1;

import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Taboo<T> {
	
	private List<T> rules;
	
	/**
	 * Constructs a new Taboo using the given rules (see handout.)
	 * @param rules rules for new Taboo
	 */
	public Taboo(List<T> rules) {
		this.rules = rules;
	}
	
	/**
	 * Returns the set of elements which should not follow
	 * the given element.
	 * @param elem
	 * @return elements which should not follow the given element
	 */
	public Set<T> noFollow(T elem) {
		// look for element
		// if it does not throw indexError
		// make a set that precedes
		Set<T> returnSet = new HashSet<T>();
		for(int i=0; i<rules.size(); i++){
			if(rules.get(i)!=null && rules.get(i).equals(elem)){
				if(i-1>=0){
					if(rules.get(i-1)!=null){
						returnSet.add(rules.get(i-1));
					}
				}
			}
		}
		 return returnSet;
	}
	
	/**
	 * Removes elements from the given list that
	 * violate the rules (see handout).
	 * @param list collection to reduce
	 */
	public void reduce(List<T> list) {
		for(int i=0; i<list.size(); i++){
			T element=list.get(i);
			if(i-1>=0 && i-1<list.size()){
				Set<T> shouldNot = noFollow(element);
				T prev = list.get(i-1);
				if(shouldNot.contains(prev)){
					//System.out.println(list.get(i));
					list.remove(i);
					i = i-1;
				}
			}
		}
		// for all element
		// if previous element is in nofollows
		// remove it and change the string
		// then initialize the index - maybe possibly i-1
	}
}
