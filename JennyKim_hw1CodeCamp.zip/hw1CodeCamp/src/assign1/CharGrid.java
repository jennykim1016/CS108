// HW1 2-d array Problems
// CharGrid encapsulates a 2-d grid of chars and supports
// a few operations on the grid.

package assign1;

import java.util.Set;

public class CharGrid {
	private char[][] grid;

	/**
	 * Constructs a new CharGrid with the given grid.
	 * Does not make a copy.
	 * @param grid
	 */
	public CharGrid(char[][] grid) {
		this.grid = grid;
	}
	
	/**
	 * Returns the area for the given char in the grid. (see handout).
	 * @param ch char to look for
	 * @return area for given char
	 */
	public int charArea(char ch) {
		int rowMax = -1;
		int rowMin = -1;
		int columnMax = -1;
		int columnMin = -1;
		for (int i=0; i<grid.length; i++){
			for (int j=0; j<grid[0].length; j++){
				if(grid[i][j]==ch){
					if(rowMax < i || rowMax == -1){
						rowMax = i;
					}
					if(rowMin > i || rowMin == -1){
						rowMin = i;
					}
					if(columnMax < j || columnMax == -1){
						columnMax = j;
					}
					if(columnMin > j || columnMin == -1){
						columnMin = j;
					}
				}
			}
		}
		
		if (columnMax == -1 && columnMin == -1 && rowMax == -1 && rowMin == -1){
			return 0;
		}
		
		int rowDiff = rowMax - rowMin;
		
		int columnDiff = columnMax - columnMin;
		return (rowDiff+1)*(columnDiff+1);
	}
	
	/**
	 * Returns the count of '+' figures in the grid (see handout).
	 * @return number of + in grid
	 */
	public int countPlus() {
		int count = 0;
		for(int i=0; i<grid.length; i++){
			for(int j=0; j<grid[0].length; j++){
				if(findCross(i, j)){
					count++;
				}
			}
		}
		return count;
	}
	
	private boolean findCross(int row, int column){
		int leftRow = leftRowLength(row, column);
		int rightRow = rightRowLength(row, column);
		int upColumn = upColumnLength(row, column);
		int bottomColumn = downColumnLength(row, column);
		if (leftRow!=1 && (leftRow==rightRow) && (upColumn==bottomColumn) && (bottomColumn==rightRow)){
			return true;
		}
		return false;
	}
	
	private int leftRowLength(int row, int column){
		int count = 1;
		char centerChar = grid[row][column];
		while(true){
			row = row-1;
			if(row<0 || row>grid.length-1) break;
			if(grid[row][column] != centerChar){
				break;
			} else {
				count++;
			}
		}
		return count;
	}
	
	private int rightRowLength(int row, int column){
		int count = 1;
		char centerChar = grid[row][column];
		while(true){
			row = row+1;
			if(row<0 || row>grid.length-1) break;
			if(grid[row][column] != centerChar){
				break;
			} else {
				count++;
			}
		}
		return count;
	}
	
	private int upColumnLength(int row, int column){
		int count = 1;
		char centerChar = grid[row][column];
		while(true){
			column = column+1;
			if(column<0 || column>grid[0].length-1) break;
			if(grid[row][column] != centerChar){
				break;
			} else {
				count++;
			}
		}
		return count;
	}
	
	private int downColumnLength(int row, int column){
		int count = 1;
		char centerChar = grid[row][column];
		while(true){
			column = column-1;
			if(column<0 || column>grid[0].length-1) break;
			if(grid[row][column] != centerChar){
				break;
			} else {
				count++;
			}
		}
		return count;
	}
	
}
