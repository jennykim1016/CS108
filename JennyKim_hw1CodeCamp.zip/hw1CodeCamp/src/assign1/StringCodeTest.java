// StringCodeTest
// Some test code is provided for the early HW1 problems,
// and much is left for you to add.

package assign1;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringCodeTest {
	
	
	@Test
	public void testBlowup1() {
		// basic cases
		assertEquals("xxaaaabb", StringCode.blowup("xx3abb"));
		assertEquals("xxxZZZZ", StringCode.blowup("2x3Z"));
	}
	
	@Test
	public void testBlowup2() {
		// things with digits
		
		// digit at end
		assertEquals("axxx", StringCode.blowup("a2x3"));
		
		// digits next to each other
		assertEquals("a33111", StringCode.blowup("a231"));
		
		// try a 0
		assertEquals("aabb", StringCode.blowup("aa0bb"));
	}
	
	@Test
	public void testBlowup3() {
		// weird chars, empty string
		assertEquals("AB&&,- ab", StringCode.blowup("AB&&,- ab"));
		assertEquals("", StringCode.blowup(""));
		
		// string with only digits
		assertEquals("", StringCode.blowup("2"));
		assertEquals("33", StringCode.blowup("23"));
	}
	
	@Test
	public void testBlowup4() {
		assertEquals("", StringCode.blowup("2"));
		assertEquals("", StringCode.blowup("3"));
		assertEquals("", StringCode.blowup(""));
		assertEquals("a", StringCode.blowup("a"));
	}
	
	@Test
	public void testBlowup5() {
		assertEquals("aaaxxxx66666", StringCode.blowup("2a3x56"));
	}
	
	@Test
	public void testRun1() {
		assertEquals(2, StringCode.maxRun("hoopla"));
		assertEquals(3, StringCode.maxRun("hoopllla"));
	}
	
	
	@Test
	public void testRun2() {
		assertEquals(3, StringCode.maxRun("abbcccddbbbxx"));
		assertEquals(0, StringCode.maxRun(""));
		assertEquals(3, StringCode.maxRun("hhhooppoo"));
	}
	
	@Test
	public void testRun3() {
		// "evolve" technique -- make a series of test cases
		// where each is change from the one above.
		assertEquals(1, StringCode.maxRun("123"));
		assertEquals(2, StringCode.maxRun("1223"));
		assertEquals(2, StringCode.maxRun("112233"));
		assertEquals(3, StringCode.maxRun("1112233"));
	}
	
	@Test
	public void testRun4() {
		assertEquals(2, StringCode.maxRun("aabb"));
		assertEquals(2, StringCode.maxRun("ccddcdcd"));
	}
	
	@Test
	public void testRun5() {
		assertEquals(3, StringCode.maxRun("aaabb"));
		assertEquals(3, StringCode.maxRun("ccdddcdcd"));
	}
	
	@Test
	public void testStringIntersect1() {
		// "evolve" technique -- make a series of test cases
		// where each is change from the one above.
		assertEquals(true, StringCode.stringIntersect("aaa", "aaa", 1));
		assertEquals(true, StringCode.stringIntersect("aaa", "aaa", 2));
		assertEquals(true, StringCode.stringIntersect("aaa", "aaa", 3));
		assertEquals(false, StringCode.stringIntersect("aaa", "aaa", 4));
	}
	
	@Test
	public void testStringIntersect2() {
		// "evolve" technique -- make a series of test cases
		// where each is change from the one above.
		assertEquals(true, StringCode.stringIntersect("abba", "bbaa", 1));
		assertEquals(true, StringCode.stringIntersect("abba", "bbaa", 2));
		assertEquals(true, StringCode.stringIntersect("abba", "bbaa", 3));
		assertEquals(false, StringCode.stringIntersect("abbb", "baab", 4));
	}
	
	@Test
	public void testStringIntersect3() {
		// "evolve" technique -- make a series of test cases
		// where each is change from the one above.
		
		assertEquals(false, StringCode.stringIntersect("", "bbaa", 1));
		assertEquals(false, StringCode.stringIntersect("bbaa", "", 1));
		assertEquals(true, StringCode.stringIntersect("ab", "aaaaabbbbb", 2));
	}
	
	@Test
	public void testStringIntersect4() {
		assertEquals(true, StringCode.stringIntersect("bbaa", "bbaa", 1));
		assertEquals(true, StringCode.stringIntersect("bbaa", "bbaa", 2));
		assertEquals(true, StringCode.stringIntersect("bbaa", "bbaa", 3));
		assertEquals(true, StringCode.stringIntersect("bbaa", "bbaa", 4));
	}
	
	@Test
	public void testStringIntersect5() {
		assertEquals(true, StringCode.stringIntersect("aba", "a", 1));
		assertEquals(false, StringCode.stringIntersect("acaad", "a", 2));
		assertEquals(false, StringCode.stringIntersect("aaaaaa", "a", 3));
		assertEquals(false, StringCode.stringIntersect("ascdf", "a", 4));
	}
	
}
