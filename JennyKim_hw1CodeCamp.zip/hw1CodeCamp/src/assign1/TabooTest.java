// TabooTest.java
// Taboo class tests -- nothing provided.
package assign1;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.*;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class TabooTest {
	
	@Test
	public void testTaboo1() {
		List<String> list = new ArrayList<String>(Arrays.asList("a", "b", "c", "d"));
		Taboo<String> constructor1 = new Taboo<String>(list);
		Set<String> result = new HashSet<String>();
		result.add("a");
		assertEquals(result, constructor1.noFollow("b"));		
		List<String> test = new ArrayList<String>(Arrays.asList("a", "b", "b", "a"));
		constructor1.reduce(test);
		List<String> resultTest = new ArrayList<String>(Arrays.asList("a", "a"));
		assertEquals(resultTest, test); 
	}
	
	@Test
	public void testTaboo2() {
		List<String> list = new ArrayList<String>(Arrays.asList("a", "b", "a", "a", "c", "b", "d"));
		Taboo<String> constructor1 = new Taboo<String>(list);
		Set<String> result1 = new HashSet<String>();
		result1.add("a");
		result1.add("c");
		assertEquals(result1, constructor1.noFollow("b"));
		List<String> test = new ArrayList<String>(Arrays.asList("a", "b", "b", "a", "a"));
		constructor1.reduce(test);
		List<String> resultTest = new ArrayList<String>(Arrays.asList("a"));
		assertEquals(resultTest, test);
	}
	
	@Test
	public void testTaboo3() {
		List<String> list = new ArrayList<String>(Arrays.asList("a", null, "b", "a", "c", "b"));
		Taboo<String> constructor1 = new Taboo<String>(list);
		Set<String> result1 = new HashSet<String>();
		result1.add("c");
		assertEquals(result1, constructor1.noFollow("b"));
		List<String> test = new ArrayList<String>(Arrays.asList("a", null, "b", null, "b", null, "a"));
		constructor1.reduce(test);
		List<String> resultTest = new ArrayList<String>(Arrays.asList("a", null, "b", null, "b", null, "a"));
		assertEquals(resultTest, test);
	}
	
	@Test
	public void testTaboo4() {
		List<String> list = new ArrayList<String>(Arrays.asList(""));
		Taboo<String> constructor1 = new Taboo<String>(list);
		Set<String> result1 = new HashSet<String>();
		assertEquals(result1, constructor1.noFollow("b"));
		assertEquals(result1, constructor1.noFollow(""));
		List<String> test = new ArrayList<String>(Arrays.asList("a", "b", "b", "a", "a"));
		constructor1.reduce(test);
		List<String> resultTest = new ArrayList<String>(Arrays.asList("a", "b", "b", "a", "a"));
		assertEquals(resultTest, test);
	}
	
	@Test
	public void testTaboo5() {
		List<String> list = new ArrayList<String>(Arrays.asList("a", "b", "a", "c", "b"));
		Taboo<String> constructor1 = new Taboo<String>(list);
		Set<String> result1 = new HashSet<String>();
		assertEquals(result1, constructor1.noFollow("z"));
		List<String> test = new ArrayList<String>(Arrays.asList("z"));
		constructor1.reduce(test);
		List<String> resultTest = new ArrayList<String>(Arrays.asList("z"));
		assertEquals(resultTest, test);
	}

}
