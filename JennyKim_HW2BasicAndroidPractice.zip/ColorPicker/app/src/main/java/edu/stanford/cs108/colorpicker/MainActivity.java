package edu.stanford.cs108.colorpicker;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void changeColor(View view) {
        SeekBar redBar = (SeekBar) findViewById(R.id.seekBarRed);
        int red = redBar.getProgress();
        SeekBar blueBar = (SeekBar) findViewById(R.id.seekBarBlue);
        int blue = blueBar.getProgress();
        SeekBar greenBar = (SeekBar) findViewById(R.id.seekBarGreen);
        int green = greenBar.getProgress();
        TextView colorText = (TextView) findViewById(R.id.colorText);
        colorText.setText("Red: " + red + ", Green " + green + ", Blue " + blue);
        LinearLayout colorMain = (LinearLayout) findViewById(R.id.mainColor);
        colorMain.setBackgroundColor(Color.rgb(red,green,blue));
    }

}
