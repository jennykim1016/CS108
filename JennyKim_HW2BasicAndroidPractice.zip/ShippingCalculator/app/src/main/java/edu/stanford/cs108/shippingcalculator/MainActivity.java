package edu.stanford.cs108.shippingcalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup radioButtonGroup = (RadioGroup) findViewById(R.id.radioButtonGroup);
        //http://stackoverflow.com/questions/9175635/how-to-set-radio-button-checked-as-default-in-radiogroup-with-android
        radioButtonGroup.check(R.id.initialCheck);
    }

    private int oneDay = 10;
    private int twoDay = 5;
    private int standard = 3;
    private int totalCost = 0;

    public void calculate(View view) {
        // get text
        EditText inputText = (EditText) findViewById(R.id.editText);
        double weight = Double.parseDouble(inputText.getText().toString());
        RadioGroup radioButtonGroup = (RadioGroup) findViewById(R.id.radioButtonGroup);
        RadioButton selectedButton = (RadioButton) findViewById(radioButtonGroup.getCheckedRadioButtonId());
        String text = (String) selectedButton.getText().toString();
        //https://www.google.com/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=strip%20white%20space%20java
        if(text.equals("Next Day")){
            totalCost = (int) Math.round(weight * oneDay);
        } else if(text.equals("Second Day")){
            totalCost = (int) Math.round(weight * twoDay);
        } else{
            totalCost = (int) Math.round(weight * standard);
        }
        CheckBox checkbox = (CheckBox) findViewById(R.id.checkBox);
        if(checkbox.isChecked()){
            totalCost = (int) Math.round(totalCost * 1.2);
        }
        TextView cost = (TextView) findViewById(R.id.cost);
        cost.setText("Cost: $" + String.format("%s", totalCost));
    }
}
