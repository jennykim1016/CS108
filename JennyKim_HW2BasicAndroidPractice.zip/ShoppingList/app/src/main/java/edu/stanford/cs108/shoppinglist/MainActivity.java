package edu.stanford.cs108.shoppinglist;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> nameList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void add(View view) {
        EditText editText = (EditText) findViewById(R.id.ShoppingTextField);
        TextView mainText = (TextView) findViewById(R.id.mainText);
        nameList.add(editText.getText().toString());
        mainText.setText("");
        //http://stackoverflow.com/questions/10665143/android-how-to-set-value-of-arraylist-to-textview
        for (int j = 0; j < nameList.size(); j++){
            mainText.append(nameList.get(j) + "\n");
        }

    }

    public void clear(View view) {
        TextView mainText = (TextView) findViewById(R.id.mainText);
        mainText.setText("");
        nameList.clear();
    }

}
